    export default function NewsPage() {
        return (
            <> 
            <h1> <center> News Updates Today </center> </h1>
            <h2> Security & Safety 
We trailed female suicide bomber for 5 days – UPDF: Security forces reportedly tracked a suspected female suicide bomber for five days before she was shot dead at Kalerwe Market in Kampala. (Monitor, Nile Post)
Five Killed in Buyende Road Crash as Police Suspect Drunk Driving:1 A fatal road accident in Buyende has claimed five lives, with drunk driving being a suspected cause.2 (Nile Post)
Vandals Blamed for Darkness on Kampala Northern Bypass Despite New Streetlights: Vandalism is being cited as the reason for streetlights not working on the Northern Bypass.3 (Nile Post)
 </h2>cls
            <h3> Product 2 </h3>
            <h4> Product 3 </h4>
           
            
            </>
        )
        }